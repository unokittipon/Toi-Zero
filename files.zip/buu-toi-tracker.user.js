// ==UserScript==
// @name         BUU TOI Progress Tracker
// @namespace    https://toi-coding.informatics.buu.ac.th/
// @version      3.0.0
// @description  Tracks A1 (20) and A2+A3 (20) goals on every contest page, with statement download buttons
// @match        https://toi-coding.informatics.buu.ac.th/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  function isPractice(group, num) {
    if (group === "A1" && num >= 2 && num <= 40 && num % 2 === 0) return true;
    if (group === "A2" && num >= 2 && num <= 32 && num % 2 === 0) return true;
    return false;
  }
  var A1_GOAL = 20, A23_GOAL = 20;
  var STORAGE_KEY = "buuTrackerSnapshot";
  var contestSlug = (location.pathname.split("/").filter(function (x) { return x; })[0]) || "00-pre-toi";
  var overviewUrl = "/" + contestSlug;

  // ---- Inject styles ----
  if (!document.getElementById("buu-tracker-styles")) {
    var styles = document.createElement("style");
    styles.id = "buu-tracker-styles";
    styles.textContent = "table.main_task_list tr.bt-solved td.public_score{background:#d1fadf!important;color:#054f31!important;font-weight:700}table.main_task_list tr.bt-partial td.public_score{background:#fef3c7!important;color:#78350f!important;font-weight:700}table.main_task_list tr.bt-untouched td.public_score{background:#fee2e2!important;color:#7f1d1d!important}table.main_task_list tr.bt-prac{opacity:.55}table.main_task_list tr.bt-prac th{border-left:3px solid #94a3b8!important;font-style:italic}#buu-tracker-panel{position:fixed;right:20px;bottom:20px;width:360px;max-height:80vh;display:flex;flex-direction:column;background:#0f172a;color:#e2e8f0;border-radius:14px;box-shadow:0 20px 50px rgba(0,0,0,.4),0 0 0 1px rgba(148,163,184,.15);font-family:ui-sans-serif,-apple-system,'Segoe UI',Roboto,sans-serif;font-size:13px;z-index:2147483646;overflow:hidden;transition:max-height .25s,width .25s}#buu-tracker-panel.collapsed{max-height:44px;width:200px}#buu-tracker-panel.collapsed .bt-body{display:none}.bt-header{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:linear-gradient(135deg,#1e293b,#0f172a);border-bottom:1px solid rgba(148,163,184,.15)}.bt-title{display:flex;align-items:center;gap:8px;font-weight:600}.bt-dot{width:8px;height:8px;border-radius:50%;background:#f59e0b;box-shadow:0 0 8px #f59e0b}.bt-dot.win{background:#34d399;box-shadow:0 0 8px #34d399}.bt-stale{margin-left:6px;font-size:9px;font-weight:600;text-transform:uppercase;color:#94a3b8;background:rgba(148,163,184,.18);padding:2px 6px;border-radius:4px}.bt-toggle{background:transparent;color:#cbd5e1;border:1px solid rgba(148,163,184,.3);width:24px;height:24px;border-radius:6px;cursor:pointer;font-size:14px;line-height:1;display:flex;align-items:center;justify-content:center;padding:0}.bt-body{display:flex;flex-direction:column;overflow:hidden}.bt-loading{text-align:center;padding:32px 16px;color:#94a3b8;font-size:13px}.bt-loading-sub{margin-top:6px;font-size:11px;color:#64748b}.bt-goals{display:flex;flex-direction:column;gap:8px;padding:12px 14px 4px}.bt-goal{background:rgba(30,41,59,.6);border:1px solid rgba(148,163,184,.15);border-radius:8px;padding:10px 12px}.bt-goal.met{background:rgba(16,185,129,.12);border-color:rgba(16,185,129,.4)}.bt-goal-head{display:flex;justify-content:space-between;margin-bottom:6px}.bt-goal-name{font-size:12px;font-weight:600;color:#cbd5e1}.bt-goal.met .bt-goal-name{color:#34d399}.bt-goal-count{font-size:14px;font-weight:700;color:#fff}.bt-goal-bar{height:6px;background:rgba(148,163,184,.15);border-radius:3px;overflow:hidden;margin-bottom:6px}.bt-goal-bar>div{height:100%;background:linear-gradient(90deg,#3b82f6,#60a5fa)}.bt-goal.met .bt-goal-bar>div{background:linear-gradient(90deg,#10b981,#34d399)}.bt-goal-sub{font-size:11px;color:#94a3b8}.bt-goal.met .bt-goal-sub{color:#34d399}.bt-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:8px 14px}.bt-stat{display:flex;flex-direction:column;align-items:center;padding:6px 4px;border-radius:8px}.bt-stat.s{background:rgba(16,185,129,.15)}.bt-stat.p{background:rgba(245,158,11,.15)}.bt-stat.u{background:rgba(239,68,68,.15)}.bt-stat.pr{background:rgba(148,163,184,.18)}.bt-num{font-size:15px;font-weight:700}.bt-stat.s .bt-num{color:#34d399}.bt-stat.p .bt-num{color:#fbbf24}.bt-stat.u .bt-num{color:#f87171}.bt-stat.pr .bt-num{color:#cbd5e1;font-size:12px}.bt-lbl{margin-top:4px;font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8}.bt-tabs{display:flex;gap:4px;padding:0 14px 8px;flex-wrap:wrap}.bt-tab{flex:1 1 auto;background:transparent;border:1px solid rgba(148,163,184,.2);color:#cbd5e1;border-radius:6px;padding:5px 6px;font-size:10px;cursor:pointer;white-space:nowrap}.bt-tab.active{background:#334155;border-color:#475569;color:#fff;font-weight:600}.bt-list{flex:1;overflow-y:auto;padding:0 8px 12px;scrollbar-width:thin;scrollbar-color:#475569 transparent}.bt-list::-webkit-scrollbar{width:6px}.bt-list::-webkit-scrollbar-thumb{background:#475569;border-radius:3px}.bt-rowwrap{display:flex;align-items:stretch;border-left:3px solid transparent;border-radius:6px;margin-bottom:2px}.bt-rowwrap:hover{background:rgba(148,163,184,.08)}.bt-rowwrap.solved{border-left-color:#10b981}.bt-rowwrap.partial{border-left-color:#f59e0b}.bt-rowwrap.untouched{border-left-color:#ef4444}.bt-rowwrap.practice{opacity:.75}.bt-rowwrap.practice.untouched{border-left-color:#64748b}.bt-item{display:flex;align-items:center;gap:6px;padding:6px 6px 6px 8px;text-decoration:none;color:#e2e8f0;font-size:12px;flex:1;min-width:0}.bt-item:hover{color:#fff}.bt-dl{display:flex;align-items:center;justify-content:center;width:28px;flex-shrink:0;color:#94a3b8;text-decoration:none;border-left:1px solid rgba(148,163,184,.12);border-radius:0 6px 6px 0;transition:all .15s}.bt-dl:hover{background:rgba(59,130,246,.2);color:#93c5fd}.bt-dl svg{display:block}.bt-code{font-weight:600;font-family:ui-monospace,Menlo,monospace;color:#93c5fd;flex-shrink:0;min-width:60px}.bt-name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cbd5e1}.bt-tag{font-size:9px;font-weight:600;text-transform:uppercase;color:#94a3b8;background:rgba(148,163,184,.18);padding:2px 6px;border-radius:4px}.bt-score{font-size:10px;font-weight:600;color:#fbbf24;background:rgba(245,158,11,.15);padding:2px 6px;border-radius:4px}.bt-empty{text-align:center;color:#64748b;padding:24px;font-size:12px}.bt-grow{padding:8px;border-bottom:1px solid rgba(148,163,184,.08)}.bt-grow:last-child{border-bottom:none}.bt-ghead{display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;color:#cbd5e1}.bt-ghead strong{color:#fff}.bt-gbar{height:5px;background:rgba(148,163,184,.15);border-radius:3px;overflow:hidden}.bt-gbar>div{height:100%;background:linear-gradient(90deg,#10b981,#34d399)}#buu-tracker-task-dl{position:fixed;right:20px;bottom:20px;display:inline-flex;align-items:center;gap:8px;padding:12px 18px;background:linear-gradient(135deg,#3b82f6,#2563eb);color:#fff;font-size:13px;font-weight:600;text-decoration:none;border-radius:999px;box-shadow:0 12px 30px rgba(37,99,235,.45);z-index:2147483646}#buu-tracker-task-dl:hover{transform:translateY(-2px);color:#fff}#buu-tracker-task-dl svg{display:block}";
    document.head.appendChild(styles);
  }

  // ---- Floating download button on a task page ----
  var taskPageMatch = location.pathname.match(/\/tasks\/([A-Z0-9-]+)\/(description|submissions|statements)/i);
  if (taskPageMatch && !document.getElementById("buu-tracker-task-dl")) {
    var code = taskPageMatch[1];
    var fab = document.createElement("a");
    fab.id = "buu-tracker-task-dl";
    fab.href = "/" + contestSlug + "/tasks/" + code + "/statements/TH";
    fab.setAttribute("download", code + ".pdf");
    fab.title = "Download task statement (TH)";
    fab.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0l-5-5m5 5l5-5M5 21h14"/></svg><span>Download ' + code + "</span>";
    document.body.appendChild(fab);
  }

  // ---- Parse + summary helpers ----
  function parseDoc(doc) {
    var table = doc.querySelector("table.main_task_list");
    if (!table) return null;
    var tasks = [];
    table.querySelectorAll("tbody tr").forEach(function (row) {
      var sc = row.querySelector("td.public_score");
      var cc = row.querySelector("th");
      var nc = row.querySelectorAll("td")[1];
      if (!sc || !cc) return;
      var c = cc.textContent.trim();
      var n = nc ? nc.textContent.trim() : "";
      var m = sc.textContent.match(/(\d+)\s*\/\s*(\d+)/);
      var sv = m ? parseInt(m[1], 10) : 0;
      var mx = m ? parseInt(m[2], 10) : 100;
      var st = sv >= mx ? "solved" : sv === 0 ? "untouched" : "partial";
      var p = c.split("-");
      var g = p[0] || "?";
      var nm = parseInt(p[1], 10) || 0;
      tasks.push({ code: c, name: n, score: sv, max: mx, status: st, group: g, num: nm, practice: isPractice(g, nm) });
    });
    return { updatedAt: Date.now(), tasks: tasks, summary: summarize(tasks) };
  }

  function summarize(tasks) {
    var s = { total: tasks.length, solved: 0, partial: 0, untouched: 0, practiceTotal: 0, practiceSolved: 0, a1: { solved: 0, goal: A1_GOAL }, a23: { solved: 0, goal: A23_GOAL }, byGroup: {} };
    tasks.forEach(function (t) {
      s[t.status]++;
      if (t.practice) { s.practiceTotal++; if (t.status === "solved") s.practiceSolved++; }
      else { var b = t.group === "A1" ? "a1" : "a23"; if (t.status === "solved") s[b].solved++; }
      if (!s.byGroup[t.group]) s.byGroup[t.group] = { countingTotal: 0, countingSolved: 0, solved: 0, partial: 0, untouched: 0 };
      s.byGroup[t.group][t.status]++;
      if (!t.practice) { s.byGroup[t.group].countingTotal++; if (t.status === "solved") s.byGroup[t.group].countingSolved++; }
    });
    return s;
  }

  function decorate(tasks) {
    var table = document.querySelector("table.main_task_list");
    if (!table) return;
    var byCode = {};
    tasks.forEach(function (t) { byCode[t.code] = t; });
    table.querySelectorAll("tbody tr").forEach(function (row) {
      var cc = row.querySelector("th"); if (!cc) return;
      var t = byCode[cc.textContent.trim()]; if (!t) return;
      row.classList.add("bt-" + t.status);
      if (t.practice) row.classList.add("bt-prac");
    });
  }

  // ---- Storage (localStorage so it works without extension permissions) ----
  function saveSnap(snap) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(snap)); } catch (e) {}
  }
  function loadSnap() {
    try { var raw = localStorage.getItem(STORAGE_KEY); return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }

  // ---- Fetch overview in background ----
  function fetchOverview() {
    return fetch(overviewUrl, { credentials: "same-origin" })
      .then(function (r) { return r.ok ? r.text() : null; })
      .then(function (html) {
        if (!html) return null;
        var doc = new DOMParser().parseFromString(html, "text/html");
        return parseDoc(doc);
      })
      .catch(function () { return null; });
  }

  // ---- Render ----
  var panelEl = null;

  function escHtml(s) { return s.replace(/[&<>"']/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]; }); }

  function ensurePanel() {
    if (panelEl) return panelEl;
    panelEl = document.createElement("div");
    panelEl.id = "buu-tracker-panel";
    panelEl.dataset.bookmarklet = "1";
    if (localStorage.getItem("btCollapsed") === "1") panelEl.classList.add("collapsed");
    document.body.appendChild(panelEl);
    return panelEl;
  }

  function render(snap, isStale) {
    var p = ensurePanel();

    if (!snap) {
      p.innerHTML = '<div class="bt-header"><div class="bt-title"><span class="bt-dot"></span>TOI Progress</div><button class="bt-toggle">−</button></div><div class="bt-body"><div class="bt-loading"><div>Loading progress…</div><div class="bt-loading-sub">Fetching the contest overview</div></div></div>';
      wireToggle();
      return;
    }

    var s = snap.summary;
    var a1Done = s.a1.solved, a1Need = Math.max(0, A1_GOAL - a1Done), a1Pct = Math.min(100, (a1Done / A1_GOAL) * 100);
    var a23Done = s.a23.solved, a23Need = Math.max(0, A23_GOAL - a23Done), a23Pct = Math.min(100, (a23Done / A23_GOAL) * 100);
    var a1Met = a1Done >= A1_GOAL, a23Met = a23Done >= A23_GOAL, allMet = a1Met && a23Met;
    var stale = isStale ? '<span class="bt-stale" title="Cached \u2014 refreshing">cached</span>' : "";

    p.innerHTML = '<div class="bt-header"><div class="bt-title"><span class="bt-dot ' + (allMet ? "win" : "") + '"></span>TOI Progress' + stale + '</div><button class="bt-toggle">' + (p.classList.contains("collapsed") ? "+" : "−") + '</button></div><div class="bt-body"><div class="bt-goals"><div class="bt-goal ' + (a1Met ? "met" : "") + '"><div class="bt-goal-head"><span class="bt-goal-name">A1 goal</span><span class="bt-goal-count">' + a1Done + " / " + A1_GOAL + '</span></div><div class="bt-goal-bar"><div style="width:' + a1Pct + '%"></div></div><div class="bt-goal-sub">' + (a1Met ? "✓ goal reached" : a1Need + " more counting solves needed") + '</div></div><div class="bt-goal ' + (a23Met ? "met" : "") + '"><div class="bt-goal-head"><span class="bt-goal-name">A2 + A3 goal</span><span class="bt-goal-count">' + a23Done + " / " + A23_GOAL + '</span></div><div class="bt-goal-bar"><div style="width:' + a23Pct + '%"></div></div><div class="bt-goal-sub">' + (a23Met ? "✓ goal reached" : a23Need + " more counting solves needed") + '</div></div></div><div class="bt-stats"><div class="bt-stat s"><span class="bt-num">' + s.solved + '</span><span class="bt-lbl">Solved</span></div><div class="bt-stat p"><span class="bt-num">' + s.partial + '</span><span class="bt-lbl">Partial</span></div><div class="bt-stat u"><span class="bt-num">' + s.untouched + '</span><span class="bt-lbl">To do</span></div><div class="bt-stat pr"><span class="bt-num">' + s.practiceSolved + "/" + s.practiceTotal + '</span><span class="bt-lbl">Practice</span></div></div><div class="bt-tabs"><button class="bt-tab active" data-tab="todo-counting">To do</button><button class="bt-tab" data-tab="partial">Partial</button><button class="bt-tab" data-tab="solved">Solved</button><button class="bt-tab" data-tab="practice">Practice</button><button class="bt-tab" data-tab="groups">Groups</button></div><div class="bt-list" data-list></div></div>';

    wireToggle();
    wireTabs(snap);
    renderList(snap, "todo-counting");
  }

  function wireToggle() {
    var btn = panelEl.querySelector(".bt-toggle"); if (!btn) return;
    btn.addEventListener("click", function () {
      panelEl.classList.toggle("collapsed");
      var c = panelEl.classList.contains("collapsed");
      btn.textContent = c ? "+" : "−";
      localStorage.setItem("btCollapsed", c ? "1" : "0");
    });
  }

  function wireTabs(snap) {
    var tabs = panelEl.querySelectorAll(".bt-tab");
    tabs.forEach(function (t) {
      t.addEventListener("click", function () {
        tabs.forEach(function (x) { x.classList.remove("active"); });
        t.classList.add("active");
        renderList(snap, t.dataset.tab);
      });
    });
  }

  function renderList(snap, kind) {
    var listEl = panelEl.querySelector("[data-list]"); if (!listEl) return;
    var summary = snap.summary, tasks = snap.tasks || [];

    if (kind === "groups") {
      var groups = Object.keys(summary.byGroup).sort();
      listEl.innerHTML = groups.map(function (g) {
        var gs = summary.byGroup[g];
        var pct = gs.countingTotal === 0 ? 0 : (gs.countingSolved / gs.countingTotal) * 100;
        return '<div class="bt-grow"><div class="bt-ghead"><strong>' + g + "</strong><span>" + gs.countingSolved + "/" + gs.countingTotal + ' counting</span></div><div class="bt-gbar"><div style="width:' + pct + '%"></div></div></div>';
      }).join("");
      return;
    }

    var filtered;
    if (kind === "todo-counting") filtered = tasks.filter(function (t) { return !t.practice && t.status === "untouched"; });
    else if (kind === "practice") filtered = tasks.filter(function (t) { return t.practice; });
    else filtered = tasks.filter(function (t) { return t.status === kind; });

    if (filtered.length === 0) { listEl.innerHTML = '<div class="bt-empty">Nothing here.</div>'; return; }

    listEl.innerHTML = filtered.map(function (t) {
      var href = "/" + contestSlug + "/tasks/" + t.code + "/description";
      var dlHref = "/" + contestSlug + "/tasks/" + t.code + "/statements/TH";
      var sc = t.status === "partial" ? '<span class="bt-score">' + t.score + "/" + t.max + "</span>" : "";
      var tg = t.practice ? '<span class="bt-tag">practice</span>' : "";
      var wrapCls = "bt-rowwrap " + t.status + (t.practice ? " practice" : "");
      var icon = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0l-5-5m5 5l5-5M5 21h14"/></svg>';
      return '<div class="' + wrapCls + '"><a class="bt-item" href="' + href + '"><span class="bt-code">' + t.code + '</span><span class="bt-name">' + escHtml(t.name) + "</span>" + tg + sc + '</a><a class="bt-dl" href="' + dlHref + '" download="' + t.code + '.pdf" title="Download statement (TH)">' + icon + "</a></div>";
    }).join("");
  }

  // ---- Main flow ----
  var live = parseDoc(document);
  if (live) {
    decorate(live.tasks);
    saveSnap(live);
    render(live, false);
  } else {
    var cached = loadSnap();
    if (cached && cached.summary) render(cached, true); else render(null);
    fetchOverview().then(function (fresh) {
      if (!fresh) return;
      saveSnap(fresh);
      render(fresh, false);
    });
  }
})();
